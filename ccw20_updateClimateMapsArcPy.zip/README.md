# ccw20
Participatory modelling of site type transformation due to climate change in Swiss forests
